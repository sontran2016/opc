// COPCServerPublicGroups.cpp: implementation of the COPCServerPublicGroups class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "OPCBClient.h"
#include "OPCServerPublicGroups.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

COPCServerPublicGroups::COPCServerPublicGroups()
{

}

COPCServerPublicGroups::~COPCServerPublicGroups()
{

}

void COPCServerPublicGroups::CleanUp()
{


}
