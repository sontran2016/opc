// ConnectionPointContainer.cpp: implementation of the CConnectionPointContainer class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "OPCBClient.h"
#include "ConnectionPointContainer.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CConnectionPointContainer::CConnectionPointContainer()
{

}

CConnectionPointContainer::~CConnectionPointContainer()
{

}
